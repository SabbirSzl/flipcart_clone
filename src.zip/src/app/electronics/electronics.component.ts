import { Component } from '@angular/core';
import { ElectronicservicesService } from '../services/electronicservices.service';
@Component({
  selector: 'app-electronics',
  templateUrl: './electronics.component.html',
  styleUrls: ['./electronics.component.scss'],
  providers: [ElectronicservicesService]
})
export class ElectronicsComponent {
  electronic_products: any[] = [];
  typeOfProd: any[] = [];
  products: any[] = [];
  constructor (private electronic: ElectronicservicesService ){
    this.electronic_products = this.electronic.getElectronic_ProductsList();
    this.typeOfProd = this.electronic.getTypesofProduct();
  }

  checkchanges(){
this.products.push( ...this.electronic_products.filter(x => x.Product_type  ));
//this.products = this.electronic_products
//alert(this.products);
  }


}
