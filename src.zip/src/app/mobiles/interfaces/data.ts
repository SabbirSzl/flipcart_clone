import { MobilesComponent } from "../mobiles.component";

export interface Data extends MobilesComponent{
    FirstName: string;
    LastName: string;
    Gender: string;
    Blood: string;
}